
public class Bicycle extends Vehicle{//Bicycle inheriting from the parent class Vehicle
    public Bicycle() {
        this.setWheels(2);
    } // setting default values to the wheels using constructor
}
