/*
 * Author: Afla-Mensah Cephson
 * Programme:Biomedical Engineering
 * Index: 7078821
 * Date: 29th February, 2024
 */

public class Car extends Vehicle { // Cars inheriting from the parent class Vehicle
    public String registrationNumber;

    public Car() {
        this.setWheels(4);
    }// setting default values to the wheels using constructor
}
