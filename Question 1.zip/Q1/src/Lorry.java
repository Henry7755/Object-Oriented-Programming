/*
 * Author: Afla-Mensah Cephson
 * Programme:Biomedical Engineering
 * Index: 7078821
 * Date: 29th February, 2024
 */

public class Lorry extends Vehicle { // Lorry extending from the super Class Vehicle


    public Lorry() {
        this.setWheels(6);
    } // setting default values to the wheels using constructor

}
