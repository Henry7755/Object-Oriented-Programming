/*
 * Author: Boateng Henry Kwabena
 * Programme:Biomedical Engineering
 * Index: 7081321
 * Ref.no: 20855987
 * Date: 29th February, 2024
 */
public abstract class Quadrilateral extends Shapes { // abstract class
    public abstract  double getLength();
    public abstract  void setLength();


}
