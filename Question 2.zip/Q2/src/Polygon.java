/*
 * Author: Afla-Mensah Cephson
 * Programme:Biomedical Engineering
 * Index: 7078821
 * Date: 29th February, 2024
 */

public  interface Polygon { // interface
     double area();
}
