/*
 * Author: Boateng Henry Kwabena
 * Programme:Biomedical Engineering
 * Index: 7081321
 * Ref.no: 20855987
 * Date: 29th February, 2024
 */
public class Square extends Quadrilateral implements Polygon{
    @Override
    public double getLength() {
        return 0;
    }

    @Override
    public void setLength() {}

    @Override
    public double area() {return 0;}
}
